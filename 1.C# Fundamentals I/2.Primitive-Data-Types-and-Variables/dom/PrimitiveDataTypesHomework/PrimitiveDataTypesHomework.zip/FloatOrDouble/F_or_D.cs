﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FloatOrDouble
{
    class F_or_D
    {
        static void Main(string[] args)
        {
            double var1 = 34.567839023;
            float var2 = 1.345F;
            double var3 = 8923.1234857;
            float var4=3456.091f;

            Console.WriteLine("Type Double: {0}, {1}\nType Float: {2}, {3}",var1,var3,var2,var4 );
        }
    }
}
