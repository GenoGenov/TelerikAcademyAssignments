﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6.isFemale
{
    class Gender
    {
        static void Main(string[] args)
        {
            bool isFemale = false;
            Console.WriteLine("Am I female(Geno Genov)? :\n{0}",isFemale);
        }
    }
}
