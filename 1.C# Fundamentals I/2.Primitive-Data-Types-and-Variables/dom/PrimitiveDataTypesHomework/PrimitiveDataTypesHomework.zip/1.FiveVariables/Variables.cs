﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiveVariables
{
    class Variables
    {
        static void Main(string[] args)
        {
            ushort varUshort = 52130;
            sbyte varSbyte = -115;
            int varInt = 4825932;
            byte varByte = 97;
            short varShort = -10000;
            Console.WriteLine("Variable ushort: {0}\nVariable sbyte: {1}\nVariable int: {2}\nVariable byte: {3}\nVariable short: {4}",varUshort,varSbyte,varInt,varByte,varShort);
        }
    }
}
