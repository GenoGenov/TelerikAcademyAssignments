﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    class Acc
    {
        struct Account
        {
            public string fName;
            public string mName;
            public string lName;
            public long balance;
            public string bankName;
            public string IBAN;
            public string BIC;
            public string creditCard1;
            public string creditCard2;
            public string creditCard3;
 
        }
        static void Main(string[] args)
        {
        }
    }
}
