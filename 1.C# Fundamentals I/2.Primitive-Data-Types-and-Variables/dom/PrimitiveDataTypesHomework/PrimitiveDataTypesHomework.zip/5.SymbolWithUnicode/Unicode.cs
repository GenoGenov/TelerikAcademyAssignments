﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.SymbolWithUnicode
{
    class Unicode
    {
        static void Main(string[] args)
        {
            char symbol = '\u0048';
            Console.WriteLine(symbol);
        }
    }
}
