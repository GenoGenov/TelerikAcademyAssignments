﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.PrintFirstAndLastName
{
    class Program
    {
        static void Main(string[] args)
        {
            string FName = "Geno";
            string LName = "Genov";
            Console.WriteLine(FName + " " + LName);
        }
    }
}
